"""
EXPERIMENT 7A - PHASE 4: NEURON INTERVENTION
==============================================
Runs causal runtime interventions on sampled neurons and
records accuracy and continuous metrics (probability, margin).
"""

import os
import json
import torch
import pandas as pd
import types
from transformers import AutoModelForCausalLM, AutoTokenizer

from config import (
    BASE_MODEL_ID, HF_REVISION, TARGET_LAYER_IDX,
    DATA_DIR, INTERVENTION_DIR, DEVICE, DTYPE,
    ensure_dirs, mark_task, is_task_completed
)
from phase2_sensitivity import format_arc_question, compute_choice_logprob, patched_experts_forward

def evaluate_on_dataset(model, tokenizer, dataset, mask_config=None):
    """
    Evaluates the model on the dataset. If mask_config=(expert_id, neuron_idx),
    masks that specific neuron in the patched forward pass.
    """
    experts_module = model.model.layers[TARGET_LAYER_IDX].mlp.experts
    experts_module._mask_config = mask_config
    
    correct_count = 0
    total = len(dataset)
    
    sum_p_correct = 0.0
    sum_margin = 0.0
    
    for item in dataset:
        prompt, candidates, correct_idx = format_arc_question(item)
        
        log_probs = []
        for choice in candidates:
            log_probs.append(compute_choice_logprob(model, tokenizer, prompt, choice))
            
        log_probs = torch.stack(log_probs)
        probs = torch.nn.functional.softmax(log_probs, dim=0)
        
        pred_idx = torch.argmax(probs).item()
        if pred_idx == correct_idx:
            correct_count += 1
            
        p_correct = probs[correct_idx].item()
        sum_p_correct += p_correct
        
        # Margin: P(correct) - max(P(incorrect))
        incorrect_probs = torch.cat([probs[:correct_idx], probs[correct_idx+1:]])
        max_incorrect_prob = torch.max(incorrect_probs).item() if len(incorrect_probs) > 0 else 0.0
        margin = p_correct - max_incorrect_prob
        sum_margin += margin
        
    accuracy = correct_count / total
    avg_p_correct = sum_p_correct / total
    avg_margin = sum_margin / total
    
    return accuracy, avg_p_correct, avg_margin

def run_interventions():
    task_id = "phase4_intervention"
    if is_task_completed(task_id):
        print("[Phase 4] Interventions already completed. Skipping.")
        return

    ensure_dirs()
    
    csv_path = os.path.join(INTERVENTION_DIR, "sampled_neurons.csv")
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"Missing {csv_path}. Run phase3 first.")
    
    sampled_df = pd.read_csv(csv_path)
    
    ds_path = os.path.join(DATA_DIR, "D_proxy.pt")
    d_proxy = torch.load(ds_path)
    print(f"[Phase 4] Loaded D_proxy ({len(d_proxy)} examples).")
    
    print(f"[Phase 4] Loading model {BASE_MODEL_ID}...")
    tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL_ID)
    model = AutoModelForCausalLM.from_pretrained(
        BASE_MODEL_ID, 
        revision=HF_REVISION,
        torch_dtype=DTYPE, 
        device_map=DEVICE, 
        trust_remote_code=True
    )
    model.eval()
    
    # Patch the target layer
    experts_module = model.model.layers[TARGET_LAYER_IDX].mlp.experts
    experts_module.forward = types.MethodType(patched_experts_forward, experts_module)
    
    # Baseline
    print("[Phase 4] Evaluating baseline...")
    with torch.no_grad():
        base_acc, base_p_corr, base_margin = evaluate_on_dataset(model, tokenizer, d_proxy, mask_config=None)
    print(f"  Baseline Accuracy: {base_acc:.4f}, P_corr: {base_p_corr:.4f}, Margin: {base_margin:.4f}")
    
    # Interventions
    results = []
    print(f"[Phase 4] Running {len(sampled_df)} interventions...")
    
    for i, row in sampled_df.iterrows():
        expert_id = int(row['expert_idx'])
        neuron_id = int(row['neuron_idx'])
        
        print(f"  [{i+1}/{len(sampled_df)}] Masking E{expert_id} N{neuron_id}...")
        
        with torch.no_grad():
            int_acc, int_p_corr, int_margin = evaluate_on_dataset(
                model, tokenizer, d_proxy, mask_config=(expert_id, neuron_id)
            )
            
        delta_acc = base_acc - int_acc
        delta_p = base_p_corr - int_p_corr
        delta_m = base_margin - int_margin
        
        results.append({
            "expert_idx": expert_id,
            "neuron_idx": neuron_id,
            "stratum": row['stratum'],
            "T_K": row['T_K'],
            "base_acc": base_acc,
            "int_acc": int_acc,
            "delta_acc": delta_acc,
            "delta_p_correct": delta_p,
            "delta_margin": delta_m
        })

    # Save results
    results_df = pd.DataFrame(results)
    out_csv = os.path.join(INTERVENTION_DIR, "intervention_results.csv")
    results_df.to_csv(out_csv, index=False)
    
    print(f"[Phase 4] Saved intervention results to {out_csv}")
    mark_task(task_id, "completed")

if __name__ == "__main__":
    run_interventions()
