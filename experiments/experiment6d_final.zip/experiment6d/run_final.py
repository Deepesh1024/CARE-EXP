import os
import sys
import json
import subprocess
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import DIRS, ensure_dirs

def run_script(script_name):
    print(f"\n{'='*60}")
    print(f"Executing {script_name}...")
    print(f"{'='*60}")
    
    script_path = os.path.join(os.path.dirname(__file__), script_name)
    cmd = [sys.executable, script_path] + sys.argv[1:]
    result = subprocess.run(cmd)
    
    if result.returncode != 0:
        print(f"\n[ERROR] {script_name} failed with exit code {result.returncode}")
        sys.exit(result.returncode)

def generate_report():
    print("Generating EXP6D_FINAL_REPORT.md...")
    
    out_path = os.path.join(DIRS["results"], "EXP6D_FINAL_REPORT.md")
    
    # Try to load stats if available
    stats = {}
    stats_path = os.path.join(DIRS["results"], "EXP6D_STATISTICS.json")
    if os.path.exists(stats_path):
        with open(stats_path, "r") as f:
            stats = json.load(f)
            
    controls = {}
    controls_path = os.path.join(DIRS["results"], "EXP6D_CONTROL_RESULTS.parquet")
    if os.path.exists(controls_path):
        controls = pd.read_parquet(controls_path).iloc[0].to_dict()
        
    with open(out_path, "w") as f:
        f.write("# EXPERIMENT 6D: FINAL CONTROLLED INTERVENTION REPORT\n\n")
        
        f.write("## PART I: OBSERVED RESULTS & STATISTICAL EVIDENCE\n\n")
        
        if "Primary_Test" in stats:
            p_test = stats["Primary_Test"]
            f.write("### Primary Test (Delta_theta)\n")
            f.write(f"- Y ~ ||tau|| (X1) -> Linear $R^2$: {p_test['Y_vs_X1_mag_tau']['linear_r2']:.4f}\n")
            f.write(f"- Y ~ ||tau_perp|| (X2) -> Linear $R^2$: {p_test['Y_vs_X2_mag_tau_perp']['linear_r2']:.4f}\n")
            f.write(f"- Y ~ ||tau_perp|| / ||C|| (X3) -> Linear $R^2$: {p_test['Y_vs_X3_susceptibility_ratio']['linear_r2']:.4f}\n\n")
            
        if "Secondary_Test_DeltaC_perp" in stats:
            s_test = stats["Secondary_Test_DeltaC_perp"]
            f.write("### Secondary Tests\n")
            f.write(f"- ||DeltaC_perp|| ~ ||tau_perp|| / ||C|| -> Linear $R^2$: {s_test['linear_r2']:.4f}\n\n")
            
        if controls:
            f.write("### Controls\n")
            f.write(f"- Control A (Baseline Drift): {controls.get('Control_A_Baseline_Drift_deg', 0):.4f} degrees\n")
            f.write(f"- Control B (Random Drift): {controls.get('Control_B_Random_Drift_deg', 0):.4f} degrees\n")
            f.write(f"- Mean Real Response: {controls.get('Mean_Real_Response_deg', 0):.4f} degrees\n")
            f.write(f"- Control E (Seed StdDev): {controls.get('Control_E_Mean_Seed_Std_deg', 0):.4f} degrees\n")
            f.write(f"- Null C (Mag-matched shuffle) Z-Score: {controls.get('Null_C_Z_Score', 0):.2f}\n")
            f.write(f"- Null D (Dir-matched shuffle) Z-Score: {controls.get('Null_D_Z_Score', 0):.2f}\n\n")
            
        f.write("## PART II: HYPOTHESIS EVALUATION\n\n")
        
        f.write("### A. Does increasing ||tau|| increase directional movement?\n")
        f.write("*(See Y ~ X1 above)*\n\n")
        
        f.write("### B. Does increasing ||tau_perpendicular|| increase directional movement?\n")
        f.write("*(See Y ~ X2 above)*\n\n")
        
        f.write("### C. Does normalization by ||C|| improve prediction?\n")
        f.write(f"*(Falsification Check: X3 > X2? {stats.get('Falsification', {}).get('X3_better_than_X2', 'N/A')})*\n\n")
        
        f.write("### D. Are low-magnitude experts more directionally susceptible?\n")
        f.write("*(Check directional response grouped by Quantile plot)*\n\n")
        
        f.write("### E. Does the angle between C and tau matter?\n")
        f.write("*(Check delta_theta curves by target angle plot)*\n\n")
        
        f.write("### F. Is the response primarily radial, tangential, or both?\n")
        f.write("*(Check ||DeltaC_par|| and ||DeltaC_perp|| plots)*\n\n")
        
        f.write("### G. Does the effect survive baseline/random controls?\n")
        if controls:
            survives = controls.get('Mean_Real_Response_deg', 0) > max(controls.get('Control_A_Baseline_Drift_deg', 0), controls.get('Control_B_Random_Drift_deg', 0)) * 2
            f.write(f"**{'YES' if survives else 'NO'}** (Real response {controls.get('Mean_Real_Response_deg', 0):.2f} vs Baseline {controls.get('Control_A_Baseline_Drift_deg', 0):.2f})\n\n")
        else:
            f.write("*(Pending execution)*\n\n")
            
        f.write("### H. Does it replicate across seeds?\n")
        if controls:
            replicates = controls.get('Mean_Real_Response_deg', 0) > controls.get('Control_E_Mean_Seed_Std_deg', 0) * 2
            f.write(f"**{'YES' if replicates else 'NO'}** (Signal {controls.get('Mean_Real_Response_deg', 0):.2f} vs Noise {controls.get('Control_E_Mean_Seed_Std_deg', 0):.2f})\n\n")
        else:
            f.write("*(Pending execution)*\n\n")
            
        f.write("### I. Does the proposed relationship Delta_theta ~ ||tau_perp|| / ||C|| survive?\n")
        if controls and "Primary_Test" in stats:
            survives_all = (
                stats['Falsification']['X3_better_than_X2'] and 
                controls.get('Null_C_Z_Score', 0) > 3.0 and 
                controls.get('Null_D_Z_Score', 0) > 3.0
            )
            f.write(f"**{'YES. The effect is significant.' if survives_all else 'NO. It failed falsification conditions.'}**\n\n")
        else:
            f.write("*(Pending execution)*\n\n")

    print(f"Saved report template to {out_path}")

def main():
    ensure_dirs()
    
    if "--gpu" in sys.argv:
        print("\n=== RUNNING FINAL 6D GPU INTERVENTION ===")
        run_script("intervention.py")
        run_script("geometry.py")
        run_script("controls.py")
        run_script("analysis.py")
        run_script("plotting.py")
        generate_report()
        print("\n[SUCCESS] Final 6D Intervention Completed.")
    else:
        print("\n=== GENERATING 6D TARGETS ===")
        run_script("config.py")
        run_script("controlled_tau.py")
        print("\n[SUCCESS] Phase 1 Targets generated.")
        print("Run `python3 run_final.py --gpu` to execute the GPU intervention.")

if __name__ == "__main__":
    main()
