"""
EXPERIMENT 6D - INTERVENTION
============================================================
The GPU training loop executing the controlled response study.
Every experimental condition starts from the identical baseline state.
Only the targeted expert's weights are updated.
"""

import os
import sys
import torch
import numpy as np
import pandas as pd
from tqdm import tqdm
from transformers import AutoModelForCausalLM

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import DIRS, ensure_dirs, MODEL_ID, REVISION, DEVICE, DTYPE, UPDATE_STEPS, LR, BATCH_SIZE, SEEDS
from capability_probe import probe_expert_capability

class RouterOverrideHook:
    def __init__(self, target_expert_idx):
        self.target_expert_idx = target_expert_idx
        self.handle = None

    def hook_fn(self, module, args, output):
        new_output = torch.full_like(output, float('-inf'))
        new_output[:, :, self.target_expert_idx] = 10000.0
        return new_output

    def register(self, gate_module):
        self.handle = gate_module.register_forward_hook(self.hook_fn)
        
    def remove(self):
        if self.handle:
            self.handle.remove()

def set_seed(seed):
    torch.manual_seed(seed)
    np.random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

def main():
    ensure_dirs()
    if DEVICE == "cpu":
        print("WARNING: Running on CPU. This will be extremely slow.")
        
    print("Loading 6D Tau Environments...")
    df_targets = pd.read_parquet(os.path.join(DIRS["results"], "EXP6D_TAU_ACTUAL.parquet"))
    
    print("Loading Token Probes...")
    token_path = os.path.join(DIRS["exp6c_root"], "token_vectors", "EXP6C_TOKEN_CAPABILITY_VECTORS.parquet")
    df_tokens = pd.read_parquet(token_path)
    
    print("Loading Model...")
    model = AutoModelForCausalLM.from_pretrained(MODEL_ID, revision=REVISION, torch_dtype=DTYPE, device_map=DEVICE if DEVICE == "cuda:0" else None)
    if DEVICE == "mps":
        model = model.to(DEVICE)
        
    moe_blocks = [m for n, m in model.named_modules() if m.__class__.__name__ == "OlmoeSparseMoeBlock"]
    
    print("Caching exact initial checkpoint state in CPU RAM...")
    initial_state = {name: param.clone().detach().cpu() for name, param in model.named_parameters()}
    
    results = []
    
    print(f"Beginning Controlled Interventions ({len(df_targets)} conditions)...")
    
    # We will replicate ONLY the specific conditions listed in the seed controls if SEEDS are used.
    # For now, to keep the array manageable, we run the primary seed, and append SEED runs as separate rows.
    
    def run_condition(row, seed_val, is_baseline=False):
        set_seed(seed_val)
        
        layer_idx = row["layer_idx"]
        expert_idx = row["expert_idx"]
        tau_actual = np.array(row["tau_actual"])
        
        # 1. Probe Baseline C_before
        c_before = probe_expert_capability(model, moe_blocks, df_tokens, layer_idx, expert_idx)
        
        if is_baseline:
            # Control A: Baseline (no custom token routing, just generic updates)
            # Actually, baseline usually means 0 updates, but to capture optimizer variance we do normal batch
            # We will implement Control A properly in controls.py, here we just do standard intervention
            pass
            
        p_axis = tau_actual / (np.sum(tau_actual) + 1e-12)
        target_expert_module = moe_blocks[layer_idx].experts[expert_idx]
        
        optimizer = torch.optim.SGD(target_expert_module.parameters(), lr=LR)
        
        model.train()
        for param in model.parameters():
            param.requires_grad = False
        for param in target_expert_module.parameters():
            param.requires_grad = True
            
        router_hook = RouterOverrideHook(expert_idx)
        router_hook.register(moe_blocks[layer_idx].gate)
        
        # 3. Controlled Update Loop
        for step in range(UPDATE_STEPS):
            batch_input_ids = []
            batch_attention_mask = []
            
            for _ in range(BATCH_SIZE):
                axis_k = np.random.choice(10, p=p_axis)
                axis_pool = df_tokens[df_tokens["axis_idx"] == axis_k]
                sample = axis_pool.sample(1, random_state=np.random.RandomState(seed_val + step)).iloc[0]
                batch_input_ids.append(sample["input_ids"])
                batch_attention_mask.append(sample["attention_mask"])
                
            input_ids = torch.tensor(batch_input_ids).to(DEVICE)
            attention_mask = torch.tensor(batch_attention_mask).to(DEVICE)
            
            labels = input_ids.clone()
            labels[attention_mask == 0] = -100
            
            optimizer.zero_grad()
            outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
            loss = outputs.loss
            loss.backward()
            optimizer.step()
            
        router_hook.remove()
        
        # 4. Probe C_after
        c_after = probe_expert_capability(model, moe_blocks, df_tokens, layer_idx, expert_idx)
        delta_c = c_after - c_before
        
        results.append({
            "layer_idx": layer_idx,
            "expert_idx": expert_idx,
            "quantile": row["quantile"],
            "alpha": row["alpha"],
            "target_angle_deg": row["target_angle_deg"],
            "is_theta_max": row["is_theta_max"],
            "seed": seed_val,
            "tau_actual": tau_actual.tolist(),
            "C_before": c_before.tolist(),
            "C_after": c_after.tolist(),
            "DeltaC": delta_c.tolist()
        })
        
        # 5. Deterministic Reset!
        with torch.no_grad():
            for name, param in model.named_parameters():
                if param.requires_grad:
                    param.copy_(initial_state[name].to(DEVICE))
                    
    # Execute standard run (Seed 42)
    for idx, row in tqdm(df_targets.iterrows(), total=len(df_targets), desc="Standard Interventions"):
        run_condition(row, SEEDS[0])
        
    # Execute Control A (Baseline) and Control B (Random Mixture) for each unique expert
    unique_experts = df_targets.drop_duplicates(subset=["layer_idx", "expert_idx"]).copy()
    print(f"Running Control A (Baseline) and Control B (Random) for {len(unique_experts)} experts...")
    
    for _, exp_row in tqdm(unique_experts.iterrows(), total=len(unique_experts), desc="Controls A & B"):
        # Control A: Baseline (no custom routing, generic natural text update)
        # We simulate this by uniformly sampling tokens from all axes.
        # Control B is practically identical if we define generic text as a uniform capability mixture.
        # Let's explicitly define Control B as tau_actual = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1] (uniform random mixture)
        
        row_A = exp_row.copy()
        row_A["target_angle_deg"] = -1.0 # Code for Baseline
        row_A["alpha"] = 1.0
        row_A["is_theta_max"] = False
        row_A["tau_actual"] = np.zeros(10) # 0 tau for pure baseline drift measurement
        
        row_B = exp_row.copy()
        row_B["target_angle_deg"] = -2.0 # Code for Random
        row_B["alpha"] = 1.0
        row_B["is_theta_max"] = False
        row_B["tau_actual"] = np.ones(10) # Uniform mixture across all axes
        
        run_condition(row_A, SEEDS[0])
        run_condition(row_B, SEEDS[0])
        
    # Execute replicated runs (Control E) for selected critical conditions
    # We replicate: highest and lowest alpha, same direction (0) and max orthogonal (theta_max)
    critical_conditions = df_targets[
        (df_targets["alpha"].isin([0.01, 2.00])) & 
        ((df_targets["target_angle_deg"] == 0) | (df_targets["is_theta_max"] == True))
    ]
    
    print(f"Running Control E Replications on {len(critical_conditions)} critical conditions...")
    for seed_val in SEEDS[1:]:
        for idx, row in tqdm(critical_conditions.iterrows(), total=len(critical_conditions), desc=f"Replication Seed {seed_val}"):
            run_condition(row, seed_val)
            
    df_res = pd.DataFrame(results)
    out_path = os.path.join(DIRS["results"], "EXP6D_RAW_RESULTS.parquet")
    df_res.to_parquet(out_path)
    print(f"Saved {len(results)} raw intervention results to {out_path}")

if __name__ == "__main__":
    if "--pilot" not in sys.argv:
        print("Run with --pilot to execute.")
        sys.exit(1)
    main()
