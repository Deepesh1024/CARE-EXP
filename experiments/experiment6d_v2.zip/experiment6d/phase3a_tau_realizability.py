import os
import pandas as pd
import numpy as np
from scipy.optimize import nnls

from config import DIRS, ensure_dirs, FEASIBILITY_TOLERANCE

def angle_between(v1, v2):
    n1 = np.linalg.norm(v1)
    n2 = np.linalg.norm(v2)
    if n1 == 0 or n2 == 0:
        return 0.0
    cos_val = np.clip(np.dot(v1, v2) / (n1 * n2), -1.0, 1.0)
    return np.degrees(np.arccos(cos_val))

def main():
    ensure_dirs()
    print("Running Phase 3A: Tau Realizability...")
    
    c_path = os.path.join(DIRS["results"], "EXP6D_SELECTED_EXPERTS.parquet")
    tau_path = os.path.join(DIRS["results"], "EXP6D_TAU_TARGETS.parquet")
    
    df_c = pd.read_parquet(c_path)
    df_targets = pd.read_parquet(tau_path)
    
    results = []
    
    # Basis matrix for the 10 capability axes (Identity matrix since they are orthogonal by definition)
    A = np.eye(10)
    
    for idx, row in df_targets.iterrows():
        c_i = np.array(df_c[(df_c["layer_idx"] == row["layer_idx"]) & (df_c["expert_idx"] == row["expert_idx"])].iloc[0]["C_i"])
        
        target = np.array(row["tau_target"])
        mag_target = np.linalg.norm(target)
        
        if mag_target == 0:
            actual = np.zeros(10)
            mag_actual = 0.0
        else:
            # 1. We solve NNLS to find the closest vector in the positive orthant to the TARGET DIRECTION
            # We preserve alpha independently as requested.
            target_dir = target / mag_target
            weights, _ = nnls(A, target_dir)
            actual_dir = np.dot(A, weights)
            
            mag_actual_dir = np.linalg.norm(actual_dir)
            
            if mag_actual_dir > 0:
                actual_dir = actual_dir / mag_actual_dir
                # Scale it to the requested magnitude
                actual = actual_dir * mag_target
            else:
                actual = np.zeros(10)
                
            mag_actual = np.linalg.norm(actual)
            
        error_norm = np.linalg.norm(actual - target)
        
        n_act = np.linalg.norm(actual)
        n_tgt = np.linalg.norm(target)
        cos_val = np.dot(actual, target) / (n_act * n_tgt) if (n_act > 0 and n_tgt > 0) else 0.0
        
        achieved_angle_to_c = angle_between(c_i, actual)
        
        # Classification
        if error_norm < FEASIBILITY_TOLERANCE * mag_target:
            status = "FEASIBLE"
        elif cos_val > 0.95:
            status = "APPROXIMATELY_FEASIBLE"
        else:
            status = "INFEASIBLE"
            
        results.append({
            "layer_idx": row["layer_idx"],
            "expert_idx": row["expert_idx"],
            "quantile": row["quantile"],
            "alpha": row["alpha"],
            "angle_fraction": row["angle_fraction"],
            "target_angle_deg": row["target_angle_deg"],
            "theta_max_deg": row["theta_max_deg"],
            "tau_target": target.tolist(),
            "tau_actual": actual.tolist(),
            "error_norm": error_norm,
            "cosine_sim": cos_val,
            "achieved_mag": mag_actual,
            "achieved_angle_deg": achieved_angle_to_c,
            "status": status
        })
        
    df_res = pd.DataFrame(results)
    out_path = os.path.join(DIRS["results"], "EXP6D_TAU_REALIZABILITY.parquet")
    df_res.to_parquet(out_path)
    print(f"Saved {len(results)} realizability results to {out_path}")
    
    # Second Geometric Analysis: Max/Min Achievable Angles in the Cone
    print("Computing Cone Boundaries...")
    boundaries = []
    for _, row in df_c.iterrows():
        c_i = np.array(row["C_i"])
        mag_c = np.linalg.norm(c_i)
        
        # Min angle to any vector in R^10_+ is 0, since C_i itself is in R^10_+
        min_angle = 0.0
        
        # Max angle to any vector in R^10_+ occurs at one of the extremal rays (the basis vectors)
        angles_to_basis = []
        for k in range(10):
            e_k = np.zeros(10)
            e_k[k] = 1.0
            angles_to_basis.append(angle_between(c_i, e_k))
            
        max_angle = max(angles_to_basis)
        
        boundaries.append({
            "layer_idx": row["layer_idx"],
            "expert_idx": row["expert_idx"],
            "quantile": row["quantile"],
            "mag_C": mag_c,
            "min_achievable_angle": min_angle,
            "max_achievable_angle": max_angle
        })
        
    df_bounds = pd.DataFrame(boundaries)
    bounds_path = os.path.join(DIRS["results"], "EXP6D_CONE_BOUNDARIES.parquet")
    df_bounds.to_parquet(bounds_path)
    print(f"Saved cone boundaries to {bounds_path}")

if __name__ == "__main__":
    main()
