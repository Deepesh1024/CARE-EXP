import os
import pandas as pd
import numpy as np

from config import DIRS, ensure_dirs, ALPHAS, NORMALIZED_ANGLE_FRACTIONS

def main():
    ensure_dirs()
    print("Constructing target tau vectors using Normalized Maximum Angles...")
    
    in_path = os.path.join(DIRS["results"], "EXP6D_SELECTED_EXPERTS.parquet")
    df = pd.read_parquet(in_path)
    
    targets = []
    
    for _, row in df.iterrows():
        c = np.array(row["C_i"])
        c = np.maximum(c, 1e-12) # numerical stability
        mag_c = np.linalg.norm(c)
        c_hat = c / mag_c
        
        # Calculate theta_max and the extremal ray e_k
        min_idx = np.argmin(c)
        theta_max_rad = np.arccos(c[min_idx] / mag_c)
        theta_max_deg = np.degrees(theta_max_rad)
        
        # Construct orthogonal vector u_hat in the plane of c_hat and e_k
        e_k = np.zeros(10)
        e_k[min_idx] = 1.0
        u = e_k - np.dot(e_k, c_hat) * c_hat
        u_hat = u / np.linalg.norm(u)
        
        for alpha in ALPHAS:
            for frac in NORMALIZED_ANGLE_FRACTIONS:
                theta_rad = frac * theta_max_rad
                theta_deg = frac * theta_max_deg
                
                # Construct target direction
                tau_hat_target = np.cos(theta_rad) * c_hat + np.sin(theta_rad) * u_hat
                
                # Scale by alpha
                tau_target = alpha * tau_hat_target
                
                targets.append({
                    "layer_idx": row["layer_idx"],
                    "expert_idx": row["expert_idx"],
                    "quantile": row["quantile"],
                    "mag_C": mag_c,
                    "alpha": alpha,
                    "angle_fraction": frac,
                    "target_angle_deg": theta_deg,
                    "theta_max_deg": theta_max_deg,
                    "tau_target": tau_target.tolist()
                })
                
    out_df = pd.DataFrame(targets)
    out_path = os.path.join(DIRS["results"], "EXP6D_TAU_TARGETS.parquet")
    out_df.to_parquet(out_path)
    print(f"Saved {len(targets)} normalized angle targets to {out_path}")

if __name__ == "__main__":
    main()
