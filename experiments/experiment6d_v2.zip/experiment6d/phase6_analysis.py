"""
EXPERIMENT 6D - PHASE 6: ANALYSIS
============================================================
Evaluates the primary hypothesis and compares the predictive power
of different normalizations.
"""

import os
import sys
import json
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import DIRS, ensure_dirs

def get_r2(x, y):
    if len(x) == 0: return 0.0
    model = LinearRegression()
    model.fit(x, y)
    return r2_score(y, model.predict(x))

def main():
    ensure_dirs()
    print("Running Phase 6: Analysis...")
    
    in_path = os.path.join(DIRS["results"], "EXP6D_GEOMETRY.parquet")
    if not os.path.exists(in_path):
        print(f"Skipping Phase 6: {in_path} not found.")
        return
        
    df = pd.read_parquet(in_path)
    
    results = {}
    
    y = df["delta_theta"].values
    
    # 8. PRIMARY HYPOTHESIS TEST
    x_tau = df["mag_tau"].values.reshape(-1, 1)
    x_tau_perp = df["mag_tau_perp"].values.reshape(-1, 1)
    x_ratio = df["susceptibility_ratio"].values.reshape(-1, 1) # ||tau_perp|| / ||C||
    
    results["Hypothesis_Test"] = {
        "R2_vs_tau": get_r2(x_tau, y),
        "R2_vs_tau_perp": get_r2(x_tau_perp, y),
        "R2_vs_tau_perp_normalized": get_r2(x_ratio, y)
    }
    
    # 10. SAME-CAPABILITY VS DIFFERENT-CAPABILITY TEST
    # Compare angle_fraction = 0.0 (Same), 0.5 (Intermediate), 1.0 (Max Orthogonal boundary)
    regimes = {}
    for frac in [0.0, 0.5, 1.0]:
        df_frac = df[np.isclose(df["angle_fraction"], frac)]
        if len(df_frac) > 0:
            regimes[f"Fraction_{frac}"] = {
                "mean_delta_theta": df_frac["delta_theta"].mean(),
                "mean_DeltaC_perp": df_frac["mag_DeltaC_perp"].mean()
            }
    results["Directional_Regimes"] = regimes
    
    # Export
    out_path = os.path.join(DIRS["results"], "EXP6D_ANALYSIS_RESULTS.json")
    with open(out_path, "w") as f:
        json.dump(results, f, indent=4)
        
    print(f"Saved analysis results to {out_path}")

if __name__ == "__main__":
    main()
