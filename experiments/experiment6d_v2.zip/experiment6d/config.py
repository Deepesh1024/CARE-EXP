import os

DIRS = {
    "root": os.path.dirname(os.path.abspath(__file__)),
    "exp6c_root": os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "results", "exp6c"),
    "exp6c_expert_vectors": os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "results", "exp6c", "expert_vectors"),
    "results": os.path.join(os.path.dirname(os.path.abspath(__file__)), "results"),
}

def ensure_dirs():
    for d in DIRS.values():
        os.makedirs(d, exist_ok=True)

NUM_LAYERS = 16
NUM_EXPERTS = 64

CHECKPOINT_TO_LOAD = "checkpoint_70"

# Target Experts Selection
QUANTILES = [0.10, 0.25, 0.50, 0.75, 0.90]
EXPERTS_PER_QUANTILE = 3

# Target Tau Construction
ALPHAS = [0.01, 0.025, 0.05, 0.10, 0.20, 0.40, 0.60, 0.80, 1.00, 1.50, 2.00]
NORMALIZED_ANGLE_FRACTIONS = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]

# Feasibility Thresholds
FEASIBILITY_TOLERANCE = 0.05 # Cosine distance tolerance or normalized magnitude tolerance
