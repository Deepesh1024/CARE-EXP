"""
EXPERIMENT 6D - PHASE 3B: CONTROLLED INTERVENTION (GPU)
============================================================
Executes the controlled response experiment by physically exposing
the selected experts to the synthetic tau environments, performing
a fixed gradient update, and measuring Delta C.
"""

import os
import sys
import gc
import torch
import numpy as np
import pandas as pd
from tqdm import tqdm
from transformers import AutoModelForCausalLM

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import DIRS, ensure_dirs

# Hardcoded for Phase 3B GPU Intervention
MODEL_ID = "allenai/OLMoE-1B-7B-0924"
REVISION = "main" # Assuming we use the base checkpoint, or the one corresponding to checkpoint_70
DEVICE = "cuda:0" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu"
DTYPE = torch.float32 # Use fp32 for stable training updates

BATCH_SIZE = 16
UPDATE_STEPS = 5
LR = 1e-4

class RouterOverrideHook:
    def __init__(self, target_expert_idx):
        self.target_expert_idx = target_expert_idx
        self.handle = None

    def hook_fn(self, module, args, output):
        # Override the router logits to strictly force routing to the target expert
        new_output = torch.full_like(output, float('-inf'))
        new_output[:, :, self.target_expert_idx] = 10000.0
        return new_output

    def register(self, gate_module):
        self.handle = gate_module.register_forward_hook(self.hook_fn)
        
    def remove(self):
        if self.handle:
            self.handle.remove()

def get_probe_norm(model, moe_blocks, df_tokens, target_layer, target_expert):
    """Measures C_i exactly like Phase 3 of 6C."""
    model.eval()
    c_raw = np.zeros(10, dtype=np.float32)
    
    # We sample a fixed small number of tokens per axis for speed during intervention testing
    SAMPLES_PER_AXIS = 10
    
    for axis_idx in range(10):
        axis_tokens = df_tokens[df_tokens["axis_idx"] == axis_idx].head(SAMPLES_PER_AXIS)
        axis_norm_sum = 0.0
        
        for _, row in axis_tokens.iterrows():
            input_ids = torch.tensor(row['input_ids']).unsqueeze(0).to(DEVICE)
            mask = torch.tensor(row['attention_mask']).unsqueeze(0).to(DEVICE)
            
            # Simple manual routing to measure output norm without full forward pass
            # (Matches 6C Phase 3)
            with torch.no_grad():
                out = model(input_ids=input_ids, attention_mask=mask, output_hidden_states=True)
                # hidden_states is a tuple. The input to target_layer is at index target_layer
                x = out.hidden_states[target_layer]
                
                exp = moe_blocks[target_layer].experts[target_expert]
                gate = torch.nn.functional.silu(torch.nn.functional.linear(x, exp.gate_proj.weight))
                up = torch.nn.functional.linear(x, exp.up_proj.weight)
                out_e = torch.nn.functional.linear(gate * up, exp.down_proj.weight)
                
                mask_t = mask.unsqueeze(-1)
                out_e = out_e * mask_t
                
                valid_len = mask.sum().item()
                if valid_len > 0:
                    axis_norm_sum += (torch.norm(out_e.float(), p=2, dim=-1).sum(dim=1) / valid_len).item()
                    
        c_raw[axis_idx] = axis_norm_sum / len(axis_tokens)
        
    return c_raw

def main():
    ensure_dirs()
    if DEVICE == "cpu":
        print("WARNING: Running on CPU. This will be extremely slow.")
        
    print("Loading 6D Targets...")
    df_targets = pd.read_parquet(os.path.join(DIRS["results"], "EXP6D_TAU_REALIZABILITY.parquet"))
    
    # Filter to feasible targets only
    df_targets = df_targets[df_targets["status"] == "FEASIBLE"].copy()
    
    print("Loading Token Probes...")
    token_path = os.path.join(DIRS["exp6c_root"], "token_vectors", "EXP6C_TOKEN_CAPABILITY_VECTORS.parquet")
    df_tokens = pd.read_parquet(token_path)
    
    print("Loading Model...")
    model = AutoModelForCausalLM.from_pretrained(MODEL_ID, revision=REVISION, torch_dtype=DTYPE, device_map=DEVICE if DEVICE == "cuda:0" else None)
    if DEVICE == "mps":
        model = model.to(DEVICE)
        
    moe_blocks = [m for n, m in model.named_modules() if m.__class__.__name__ == "OlmoeSparseMoeBlock"]
    
    # Store initial state dictionary so we can reset after each condition
    print("Caching initial weights...")
    initial_state = {name: param.clone().detach().cpu() for name, param in model.named_parameters()}
    
    results = []
    
    # To save compute, let's run a pilot on just the first 10 feasible targets
    PILOT_LIMIT = 10
    print(f"Running Pilot Intervention on {PILOT_LIMIT} targets...")
    
    for idx, row in tqdm(df_targets.head(PILOT_LIMIT).iterrows(), total=PILOT_LIMIT):
        layer_idx = row["layer_idx"]
        expert_idx = row["expert_idx"]
        tau_actual = np.array(row["tau_actual"])
        
        # 1. Measure C_before
        c_before = get_probe_norm(model, moe_blocks, df_tokens, layer_idx, expert_idx)
        
        # 2. Construct Synthetic Batch Distribution
        # Probability of choosing axis k is proportional to tau_actual[k]
        p_axis = tau_actual / (np.sum(tau_actual) + 1e-12)
        
        # Set up optimizer for ONLY the target expert
        target_expert_module = moe_blocks[layer_idx].experts[expert_idx]
        optimizer = torch.optim.SGD(target_expert_module.parameters(), lr=LR)
        
        model.train()
        # Freeze all parameters EXCEPT the target expert
        for param in model.parameters():
            param.requires_grad = False
        for param in target_expert_module.parameters():
            param.requires_grad = True
            
        # Hook the router
        router_hook = RouterOverrideHook(expert_idx)
        router_hook.register(moe_blocks[layer_idx].gate)
        
        # 3. Intervention Loop
        for step in range(UPDATE_STEPS):
            # Sample batch
            batch_input_ids = []
            batch_attention_mask = []
            
            for _ in range(BATCH_SIZE):
                axis_k = np.random.choice(10, p=p_axis)
                axis_pool = df_tokens[df_tokens["axis_idx"] == axis_k]
                sample = axis_pool.sample(1).iloc[0]
                batch_input_ids.append(sample["input_ids"])
                batch_attention_mask.append(sample["attention_mask"])
                
            input_ids = torch.tensor(batch_input_ids).to(DEVICE)
            attention_mask = torch.tensor(batch_attention_mask).to(DEVICE)
            
            # Forward pass (router hook forces our expert)
            # We use standard causal LM labels
            labels = input_ids.clone()
            labels[attention_mask == 0] = -100
            
            optimizer.zero_grad()
            outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
            loss = outputs.loss
            loss.backward()
            optimizer.step()
            
        router_hook.remove()
        
        # 4. Measure C_after
        c_after = get_probe_norm(model, moe_blocks, df_tokens, layer_idx, expert_idx)
        delta_c = c_after - c_before
        
        results.append({
            "layer_idx": layer_idx,
            "expert_idx": expert_idx,
            "quantile": row["quantile"],
            "alpha": row["alpha"],
            "angle_fraction": row["angle_fraction"],
            "target_angle_deg": row["target_angle_deg"],
            "tau_actual": tau_actual.tolist(),
            "C_before": c_before.tolist(),
            "C_after": c_after.tolist(),
            "DeltaC": delta_c.tolist()
        })
        
        # 5. Restore weights
        with torch.no_grad():
            for name, param in model.named_parameters():
                param.copy_(initial_state[name].to(DEVICE))
                
    df_res = pd.DataFrame(results)
    out_path = os.path.join(DIRS["results"], "EXP6D_INTERVENTION_RESULTS.parquet")
    df_res.to_parquet(out_path)
    print(f"Saved {len(results)} intervention results to {out_path}")

if __name__ == "__main__":
    if "--pilot" not in sys.argv:
        print("Run with --pilot flag to confirm.")
        sys.exit(1)
    main()
