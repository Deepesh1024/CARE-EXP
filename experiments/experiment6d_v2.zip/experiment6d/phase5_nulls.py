"""
EXPERIMENT 6D - PHASE 5: NULL CONTROLS
============================================================
Tests the geometric susceptibility law against randomized null distributions.
"""

import os
import sys
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import DIRS, ensure_dirs

def get_r2(x, y):
    if len(x) == 0: return 0.0
    model = LinearRegression()
    model.fit(x, y)
    return r2_score(y, model.predict(x))

def main():
    ensure_dirs()
    print("Running Phase 5: Null Controls...")
    
    in_path = os.path.join(DIRS["results"], "EXP6D_GEOMETRY.parquet")
    if not os.path.exists(in_path):
        print(f"Skipping Phase 5: {in_path} not found.")
        return
        
    df = pd.read_parquet(in_path)
    
    # We test the primary hypothesis: Delta_theta ~ ||tau_perp|| / ||C||
    # Against 5 null hypotheses by permuting the relevant columns
    
    N_PERM = 100
    
    results = {}
    
    y = df["delta_theta"].values
    x_true = df["susceptibility_ratio"].values.reshape(-1, 1)
    
    true_r2 = get_r2(x_true, y)
    results["True Model"] = {"R2": true_r2, "Z-Score": None, "p-value": None}
    
    null_conditions = {
        "A_Random_Tau_Direction": df["mag_tau_perp"].sample(frac=1).values / (df["mag_C"].values + 1e-12),
        "C_Magnitude_Shuffled_Tau": (df["mag_tau_perp"] / df["mag_tau"] * df["mag_tau"].sample(frac=1).values).values / (df["mag_C"].values + 1e-12),
        "E_Randomized_C_Direction": df["mag_tau_perp"].values / (df["mag_C"].sample(frac=1).values + 1e-12)
    }
    
    for name, permuted_x_base in null_conditions.items():
        null_r2s = []
        for _ in range(N_PERM):
            # We shuffle the base permutation again to get a distribution
            x_null = np.random.permutation(permuted_x_base).reshape(-1, 1)
            null_r2s.append(get_r2(x_null, y))
            
        mean_null = np.mean(null_r2s)
        std_null = np.std(null_r2s)
        z_score = (true_r2 - mean_null) / (std_null + 1e-12)
        
        results[name] = {
            "Mean_Null_R2": mean_null,
            "Std_Null_R2": std_null,
            "Z-Score": z_score
        }
        
    print(f"True Model R2: {true_r2:.4f}")
    for name, stats in results.items():
        if name != "True Model":
            print(f"Null [{name}]: Z-Score = {stats['Z-Score']:.2f}")
            
    out_df = pd.DataFrame(results).T
    out_path = os.path.join(DIRS["results"], "EXP6D_NULL_RESULTS.parquet")
    out_df.to_parquet(out_path)
    print(f"Saved null results to {out_path}")

if __name__ == "__main__":
    main()
