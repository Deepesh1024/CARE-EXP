import os
import pandas as pd
import numpy as np

from config import DIRS, ensure_dirs, CHECKPOINT_TO_LOAD, QUANTILES, EXPERTS_PER_QUANTILE

def main():
    ensure_dirs()
    print("Loading 6C Expert State...")
    
    c_path = os.path.join(DIRS["exp6c_expert_vectors"], "EXP6C_EXPERT_CAPABILITY_VECTORS.parquet")
    df = pd.read_parquet(c_path)
    
    # Filter to checkpoint
    df = df[df["checkpoint"] == CHECKPOINT_TO_LOAD].copy()
    
    # Calculate norms
    df["mag_C"] = df["C_raw"].apply(np.linalg.norm)
    
    # Calculate quantiles
    q_vals = np.quantile(df["mag_C"], QUANTILES)
    
    selected_experts = []
    
    for q_idx, q in enumerate(QUANTILES):
        target_mag = q_vals[q_idx]
        print(f"Targeting {q*100:.0f}th percentile: ||C|| ≈ {target_mag:.4f}")
        
        # Sort by distance to target magnitude
        df["dist_to_q"] = np.abs(df["mag_C"] - target_mag)
        sorted_df = df.sort_values("dist_to_q")
        
        # Pick top EXPERTS_PER_QUANTILE
        top_k = sorted_df.head(EXPERTS_PER_QUANTILE)
        
        for _, row in top_k.iterrows():
            selected_experts.append({
                "quantile": q,
                "layer_idx": row["layer_idx"],
                "expert_idx": row["expert_idx"],
                "C_i": row["C_raw"].tolist(),
                "mag_C": float(row["mag_C"])
            })
            
    out_df = pd.DataFrame(selected_experts)
    out_path = os.path.join(DIRS["results"], "EXP6D_SELECTED_EXPERTS.parquet")
    out_df.to_parquet(out_path)
    print(f"Saved {len(selected_experts)} selected experts to {out_path}")

if __name__ == "__main__":
    main()
